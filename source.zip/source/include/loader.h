#ifndef LOADER_H
#define LOADER_H

#include "common.h"

struct pcb_t * load(const char * path);

#endif

